<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>

<div class="vc_welcome-visible-e vc_selected-post-custom-layout-visible-e">
	<div class="vc_welcome-header vc_welcome-visible-e">
		<?php esc_html_e( 'Start by adding elements or templates', 'js_composer' ); ?>
	</div>
</div>
